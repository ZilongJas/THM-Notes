![nmap-logo-256x256-1-1773140810](https://github.com/user-attachments/assets/8caa62a1-d580-44ac-b9bb-42d1b54dc7d8)

### Nmap
- `-` to scan all the ip addresses from 192.168.0.1 to 192.168.0.10 like this `192.168.0.1-10`
- `/` for subnet
- `-sL` lists the targets without scanning them
- `-sn` discover live hosts without scanning any ports
![image](https://github.com/user-attachments/assets/d300f595-b2a8-428f-bd36-281433b7818d)
![image](https://github.com/user-attachments/assets/e06a895e-3f2e-4b04-8f1b-b42012ffea29)
![image](https://github.com/user-attachments/assets/dcc19182-ca63-437f-9e5e-133f4fc8f9ad)

-parallel probes refer to the technique of sending multiple scan requests (or probes) to different ports or hosts at the same time

- `-v` for more info and scan process. up to 4 v's
- `-d` for debugging, up to 9 d's
![image](https://github.com/user-attachments/assets/7d2dd772-21db-4743-b0d8-bb7bc0784545)
