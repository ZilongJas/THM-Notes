### Tcpdump
- general-purpose packet capture tool, capturing network traffic on any network interface (Ethernet, Wi-Fi) but usually only works in managed mode, so it’s limited in capturing wireless data unless it’s unsecured or broadcast.
![image](https://github.com/user-attachments/assets/d8df6d3f-87bf-416a-88db-8935c78f7b37)
![image](https://github.com/user-attachments/assets/7d6fef02-8883-4687-a274-100997d4affa)
![image](https://github.com/user-attachments/assets/8843bec5-3f68-40ed-ad0d-9dda1b7d6ab0)
![image](https://github.com/user-attachments/assets/17b6a17b-4d6f-4b7d-bcb1-e0bf1b133c12)
![image](https://github.com/user-attachments/assets/fe90eed6-0cf1-4ba6-95b8-aefc03a140de)
![image](https://github.com/user-attachments/assets/7de989a6-c457-487a-8d54-2e71434dbb92)
