<img src="https://github.com/user-attachments/assets/08f33f67-7bb5-4391-bda1-f0e911d98c97" width="100px" />

### Wireshark 
- Open-source, cross-platform network packet analyser tool capable of sniffing and investigating live traffic and inspecting packet captures (PCAP).
- TShark is the terminal version

